<head>
    <title> Welcome to Maisha</title>
</head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Page</title>
    <link rel="stylesheet" href="../styles/user_menu.css">
</head>
<body style="text-align:center;">
    <?php
        // Resume the session started by the verifyPatientDetails() function and reclaim the Patient_name
        $Patient_name = $_SESSION['Patient_name'];
    ?>
    <header class="page-header">
         <!--Displaying the Doctor_name on the page-->
        <span style="margin-left:50%; align=right;" id="welcome-username">Welcome, </span>
        <h1>Patient Menu</h1>
        <hr>
       </header>
    <h3>Patients List information </h3>
    <table style="text-align:center;">
        <tr bgcolor="red" align="center" >
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Birth</th>
            <th>Gender</th>
            <th>Phone</th>
        </tr>
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "Ndagano210901@";
        $dbname = "maisha";

        // Create connection
        $conn = new mysqli(
            $servername,
            $username,
            $password,
            $dbname
        );

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: "
                . $conn->connect_error);
        }
        $sql = "SELECT Id,Patient_name,Patient_email,Patient_Birth,Patient_gender,Patient_number FROM patient";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["Id"] . "</td><td>" . $row["Patient_name"] . "</td><td>" . 
                $row["Patient_email"]
                    . "</td><td>" . $row["Patient_Birth"] . "</td><td>" . $row["Patient_gender"] . 
                    "</td><td>" . $row["Patient_number"] . "</td><tr>";
            }
            echo "</table>";
        } else {
            echo "0 result";
        }
        $conn->close();
        ?>
    </table>
</body>

</html>